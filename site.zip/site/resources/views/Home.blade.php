@extends('Layout.app')
@section('content')
@include('Component.HomeBanner')
@include('Component.HomeAbout')
<!-- @include('Component.HomeBlog') -->
@include('Component.HomeWork')
@include('Component.HomeAchive')
@include('Component.HomeSocialWork')
@include('Component.HomeContact')

@endsection