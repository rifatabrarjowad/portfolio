<section id="Contact">
    <div class="container">
        <!-- Gallery -->
        <div class="row">
            <h1 style="
                color: white;
                text-align: center;
                font-size: 50px;
                font-weight: bold;
                text-decoration: underline;
                text-decoration-color: #ff8206;
              ">
                Reach Me
            </h1>
            <div class="col-sm-6 mt-5">
                <div class="ab-img">
                    <div class="con-t">
                        <h1>GitHub</h1>
                        <p><a href="https://www.github.com/rifatabrarjowad" target="_blank"> @rifatabrarjowad</a>
                        </p>
                        <h1>Youtube</h1>
                        <p><a href="https://www.youtube.com/c/RifatAbrarJowad" target="_blank">Rifat Abrar Jowad</a>
                        </p>
                        <h1>LinkedIn</h1>
                        <p><a href="https://www.linkedin.com/in/rifatabrarjowad/" target="_blank">Rifat Abrar Jowad</a>
                        </p>
                        <h1>Instagram</h1>
                        <p><a href="https://www.instagram.com/rifatabrarjowad/" target="_blank">Rifat Abrar Jowad</a>
                        </p>

                    </div>
                </div>

            </div>

            <div class="col-sm-6 mt-5   ">
                <div class="ab-img">
                    <div class="con-t">
                        <h1>Email</h1>
                        <p>rajdiprifat2004@gmail.com <span>(Always Available)</span></p>
                        <h1>Skype</h1>
                        <p> <a href="https://join.skype.com/invite/Cur9jboZspBr"
                                target="_blank">https://join.skype.com/invite/Cur9jboZspBr</a>
                            <span>(Slow response)</span>
                        </p>
                        <h1>Social</h1>
                        <p><a href="https://www.facebook.com/rifatabrarjowad" target="_blank">Facebook</a>-
                            @rifatabrarjowad <span>
                                (Recommended)</span></p>
                        <h1>Address</h1>
                        <p>Lalpur, Natore, Rajshahi, Bangladesh - 6620</p>
                    </div>
                </div>
            </div>


        </div>
        <!-- Gallery -->
    </div>
</section>