<section id="banner">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="banner-img">
                    <img width="100%" src="./img/MyImage.png" alt="banner-img" />
                </div>
            </div>
            <div class="col-md-6 m-auto">
                <div class="banner-text">
                    <h1>
                        <span style="color: #ff8206">Hey,</span> <br />
                        My Name<span style="color: red">'s</span>
                        <span style="color: #ff8206">Rifat Abrar Jowad</span>
                    </h1>
                    <p>
                        Assalamualikum! Subhanallahi Wa Bihamdihi, Subhan Allahil Azeem
                    </p>
                    <div class="action">
                        <a href="#" class="btn get">Get My CV</a>
                        <a href="#Contact" class="btn">Follow Me</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>